package com.todo.service.entities;

public enum TodoStatus {
    COMPLETED, NOT_COMPLETED;
}
